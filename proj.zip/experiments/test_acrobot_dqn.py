import os
import sys
import numpy as np
import torch
import gymnasium as gym

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dqn.agent import DQNAgent


def test_dqn(
    env_id="Acrobot-v1",
    model_path="dqn_acrobot_best.pth",
    hidden_dim=128,
    n_episodes=100,
    seed=42
):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    env = gym.make(env_id)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    agent = DQNAgent(
        state_dim=state_dim,
        action_dim=action_dim,
        hidden_dim=hidden_dim,
        lr=1e-3,
        gamma=0.99,
        epsilon_start=0.0,
        epsilon_end=0.0,
        epsilon_decay=1.0,
        buffer_capacity=50000,
        batch_size=64,
        target_update_freq=500,
        device=device
    )

    agent.load(model_path)
    agent.epsilon = 0.0
    agent.q_network.eval()

    rewards = []

    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        state = np.array(obs, dtype=np.float32)

        episode_reward = 0.0

        while True:
            action = agent.q_network.get_action(state, device)

            next_obs, reward, terminated, truncated, _ = env.step(action)

            episode_reward += reward
            state = np.array(next_obs, dtype=np.float32)

            if terminated or truncated:
                break

        rewards.append(episode_reward)

    env.close()

    rewards = np.array(rewards)

    print("\nDQN Test Results")
    print("-" * 40)
    print(f"Environment: {env_id}")
    print(f"Episodes:    {n_episodes}")
    print(f"Mode:        greedy argmax")
    print(f"Average:     {rewards.mean():.2f}")
    print(f"Std:         {rewards.std():.2f}")
    print(f"Best:        {rewards.max():.2f}")
    print(f"Worst:       {rewards.min():.2f}")
    print("-" * 40)


if __name__ == "__main__":
    test_dqn(
        env_id="Acrobot-v1",
        model_path="dqn_acrobot_best.pth",
        hidden_dim=128,
        n_episodes=100
    )
import os
import sys
import numpy as np
import torch
import gymnasium as gym
from torch.distributions import Categorical

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from policy_gradient.actor_critic import PolicyNetwork


def test_actor_critic(
    env_id="Acrobot-v1",
    model_path="actor_critic_acrobot.pth",
    hidden_dim=128,
    n_episodes=100,
    greedy=True,
    seed=42
):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    env = gym.make(env_id)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    actor = PolicyNetwork(state_dim, action_dim, hidden_dim).to(device)
    actor.load_state_dict(torch.load(model_path, map_location=device))
    actor.eval()

    rewards = []

    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        state = np.array(obs, dtype=np.float32)

        episode_reward = 0.0

        while True:
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(device)

            with torch.no_grad():
                logits = actor(state_tensor)

                if greedy:
                    action = torch.argmax(logits, dim=-1).item()
                else:
                    dist = Categorical(logits=logits)
                    action = dist.sample().item()

            next_obs, reward, terminated, truncated, _ = env.step(action)

            episode_reward += reward
            state = np.array(next_obs, dtype=np.float32)

            if terminated or truncated:
                break

        rewards.append(episode_reward)

    env.close()

    rewards = np.array(rewards)

    print("\nActor-Critic Test Results")
    print("-" * 40)
    print(f"Environment: {env_id}")
    print(f"Episodes:    {n_episodes}")
    print(f"Mode:        {'greedy argmax' if greedy else 'stochastic sampling'}")
    print(f"Average:     {rewards.mean():.2f}")
    print(f"Std:         {rewards.std():.2f}")
    print(f"Best:        {rewards.max():.2f}")
    print(f"Worst:       {rewards.min():.2f}")
    print("-" * 40)


if __name__ == "__main__":
    test_actor_critic(
        env_id="Acrobot-v1",
        model_path="actor_critic_acrobot.pth",
        hidden_dim=128,
        n_episodes=100,
        greedy=True
    )
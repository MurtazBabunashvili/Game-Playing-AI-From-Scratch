import os
import sys
import numpy as np
import torch
import gymnasium as gym

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dqn.agent import DQNAgent
from dqn.train import plot_training_curve


def evaluate_agent(agent, env_id="Acrobot-v1", n_episodes=20, seed=1000):
    env = gym.make(env_id)
    rewards = []

    old_epsilon = agent.epsilon
    agent.epsilon = 0.0

    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        state = np.array(obs, dtype=np.float32)

        episode_reward = 0.0

        while True:
            action = agent.q_network.get_action(state, agent.device)

            next_obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            episode_reward += reward
            state = np.array(next_obs, dtype=np.float32)

            if done:
                break

        rewards.append(episode_reward)

    agent.epsilon = old_epsilon
    env.close()

    return float(np.mean(rewards))


def train_acrobot_dqn(
    env_id="Acrobot-v1",
    n_episodes=2000,
    hidden_dim=128,
    lr=1e-3,
    gamma=0.99,
    epsilon_start=1.0,
    epsilon_end=0.05,
    epsilon_decay=0.997,
    buffer_capacity=50000,
    batch_size=64,
    target_update_freq=500,
    print_every=50,
    eval_every=50,
    eval_episodes=20,
    save_path="dqn_acrobot_best.pth"
):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    env = gym.make(env_id)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    agent = DQNAgent(
        state_dim=state_dim,
        action_dim=action_dim,
        hidden_dim=hidden_dim,
        lr=lr,
        gamma=gamma,
        epsilon_start=epsilon_start,
        epsilon_end=epsilon_end,
        epsilon_decay=epsilon_decay,
        buffer_capacity=buffer_capacity,
        batch_size=batch_size,
        target_update_freq=target_update_freq,
        device=device
    )

    episode_rewards = []
    best_eval_reward = -float("inf")

    for episode_i in range(n_episodes):
        obs, _ = env.reset()
        state = np.array(obs, dtype=np.float32)

        episode_reward = 0.0

        while True:
            action = agent.select_action(state)

            next_obs, reward, terminated, truncated, _ = env.step(action)

            done = terminated or truncated
            next_state = np.array(next_obs, dtype=np.float32)

            episode_reward += reward

            # Important:
            # done stops the loop, but terminated is better for TD target.
            # truncated is only time-limit ending.
            agent.store_transition(state, action, reward, next_state, terminated)

            agent.update()

            state = next_state

            if done:
                break

        episode_rewards.append(episode_reward)

        if (episode_i + 1) % print_every == 0:
            avg_reward = np.mean(episode_rewards[-print_every:])

            print(
                f"Episode {episode_i + 1:4d} / {n_episodes} | "
                f"Train avg reward (last {print_every}): {avg_reward:8.2f} | "
                f"Epsilon: {agent.epsilon:.3f}"
            )

        if (episode_i + 1) % eval_every == 0:
            eval_reward = evaluate_agent(
                agent,
                env_id=env_id,
                n_episodes=eval_episodes,
                seed=10000 + episode_i
            )

            print(
                f"Evaluation after episode {episode_i + 1:4d}: "
                f"avg reward over {eval_episodes} episodes = {eval_reward:8.2f}"
            )

            if eval_reward > best_eval_reward:
                best_eval_reward = eval_reward
                agent.save(save_path)

                print(
                    f"BEST MODEL SAVED | "
                    f"Eval reward: {best_eval_reward:.2f} | "
                    f"Path: {save_path}"
                )

    env.close()

    print(f"\nTraining finished.")
    print(f"Best evaluation reward: {best_eval_reward:.2f}")
    print(f"Best model saved to: {save_path}")

    return episode_rewards


if __name__ == "__main__":
    rewards = train_acrobot_dqn(
        env_id="Acrobot-v1",
        n_episodes=1000,
        hidden_dim=128,
        lr=1e-3,
        gamma=0.99,
        epsilon_start=1.0,
        epsilon_end=0.05,
        epsilon_decay=0.997,
        buffer_capacity=50000,
        batch_size=64,
        target_update_freq=500,
        print_every=50,
        eval_every=50,
        eval_episodes=20,
        save_path="dqn_acrobot_best.pth"
    )

    plot_training_curve(
        rewards,
        title="DQN on Acrobot-v1",
        window=50
    )